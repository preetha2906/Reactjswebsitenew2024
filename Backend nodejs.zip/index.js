const express = require("express");
const cors = require("cors");
require("./db/config")
const User = require('./db/User');
const Product = require('./db/Product')
const app = express();
// Mock user data
// const users = [
//     { id: 1, email: 'user@example.com', password: 'password123' },
//     // Add more user data as needed
//   ];


app.use(express.json());
app.use(cors());

app.post("/register",async(req,resp)=>{
    let user =  new User(req.body);
    let result = await user.save();
    result = result.toObject()
    delete result.password
resp.send(result)
})
 // Sign-in endpoint

// Sign-in endpoint
app.post('/sign-in', async(req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
console.log("00000",user)

  // Find the user by email

  if (user.email !== email) {
    // User not found
    return res.status(401).json({ message: 'Invalid email ' });
  }

  if (user.password !== password) {
    // Incorrect password
    return res.status(401).json({ message: 'Invalid password' });
  }

  // // Successful sign-in
  
  res.json({ message: 'Sign in successful' });
});
app.post("/login",async(req,resp)=>{
    if(req.body.password&&req.body.email){
        let user = await User.findOne(req.body).select('-password')
        if(user){
            resp.send(user)
        }else{
            resp.send({result:"No user found"})
        }
    }
    else{
        resp.send({result:"No user found"})
    }
})

app.post("/add-product",async(req,resp)=>{
let product = new Product(req.body);
let result = await product.save();
resp.send(result);
})


// app.listen(4000);
const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
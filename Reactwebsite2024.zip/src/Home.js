import React, { useState } from "react";
import { Link } from "react-router-dom";
import {translations} from './translation'

export default function Home(props){
   const {selectedLanguage}=props

    return(
        <>
        <main>
        <h1 style={{display: selectedLanguage === 'en' ? 'block' : 'none'}}>{translations['en']['home']}</h1>
        <h1 style={{display: selectedLanguage === 'ar' ? 'block' : 'none'}}>{translations['ar']['home']}</h1>
        </main>
        <nav>
            <Link to='/about' style={{display: selectedLanguage === 'en' ? 'block' : 'none'}}> {translations['en']['we are']}</Link>
            <Link to='/about' style={{display: selectedLanguage === 'ar' ? 'block' : 'none'}}> {translations['ar']['we are']}</Link>
        </nav>
        </>
    )
}
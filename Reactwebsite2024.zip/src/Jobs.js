import React from "react";
import { Link } from "react-router-dom";

export default function Jobs(){
    return(
        <>
        <main>
        <h1>We Are!!</h1>
        </main>
        <nav>
            <Link to='/Home' >Jobs Hire</Link>
        </nav>
        </>
    )
}
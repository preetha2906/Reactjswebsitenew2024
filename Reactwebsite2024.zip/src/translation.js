import React from "react";
export const translations = {
    'en': {
      'header': 'Spring',
      'paragraf': 'Hello',
      'lang-choice': 'Choose your language:',
      "home":'Home',
      'about':'About Us',
      'services':'Services',
      'jobs':'Jobs',
      'contact':'Contact Us',
      'we are':'We are',
      'who we are':'Who we are?'
    },
    'ar': {
      'header': 'Весна',
      'paragraf': 'Привет',
      'lang-choice': 'Выберите ваш язык:',
      'home':'بيت',
      'about':'عن',
      'services':'خدمات',
      'jobs':'وظائف',
      'contact':'اتصل بنا ',
      'we are':'نحن',
      'who we are':'من نحن؟      '
    }
  };


import './App.css';
import About from './About';
import Home from './Home';
import { Route, Routes } from 'react-router-dom';
import Contact from './Contact';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHouse, faAddressBook, faRing, faStoreAlt, faInbox, faContactBook, faCircleInfo } from '@fortawesome/free-solid-svg-icons';
import Services from './Services';
import Jobs from './Jobs';
import { useState } from 'react';
import {translations} from './translation'
const languages = [
  { code: 'en', name: 'English' },
  { code: 'ar', name: 'العربية' }
];


function App() {
  const [isNavOpen, setIsNavOpen] = useState(false);

  const toggleMenu = () => {
    console.log("isNavOpen",isNavOpen)
    setIsNavOpen(!isNavOpen);
  };
  console.log("isNavOpen", isNavOpen)
  const [isCollapsed, setCollapsed] = useState(false)

  const toggleCollapse = () => {
    setCollapsed(!isCollapsed);
  };
  const [iconStyle, setIconStyle] = useState({
    transition: ' color 0.3s',
    color: '#B6B4B4', 
  });
  const iconHoverStyle = {
    color: '#FFC20F',  
  };
  const [abouticon, setAbouticon] = useState({
    fontSize: '20px',
    transition: 'font-size 0.3s, color 0.3s',
    color: '#B6B4B4',
  })
  const aboutHoverStyle = {
    color: '#FFC20F',
    fontSize: '20px',
  };
  const [serviceicon, setServiceicon] = useState({
    transition: ' color 0.3s',
    color: '#B6B4B4',
  })
  const serviceHoverStyle = {
    color: '#FFC20F',
  };
  const [jobicon, setJobicon] = useState({
    transition: ' color 0.3s',
    color: '#B6B4B4',
  })
  const jobHoverStyle = {
    color: '#FFC20F',
  };
  const [contacticon, setContacticon] = useState({
    transition: ' color 0.3s',
    color: '#B6B4B4',
  })
  const contactHoverStyle = {
    color: '#FFC20F', 
  };
  const [selectedLanguage, setSelectedLanguage] = useState('en');

  const handleLanguageChange = (event) => {
    console.log("handleLanguageChange",event)
    setSelectedLanguage(event);
  };
  return (
    <div className="App">
      <nav className="navbar navbar-expand-lg navbar-dark fixed-top bg-light" id="mainNav">
        <div className="container">
          <a className="navbar-brand js-scroll-trigger" href="#page-top">RawHas</a>
          {/* <button onClick={toggleCollapse} className="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"  aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
            Menu
            <i className="fa fa-bars"></i>
          </button> */}
           <button onClick={toggleCollapse} className="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"  aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
          <div className={`collapse navbar-collapse ${isCollapsed ? '' : 'show'}`} id="navbarResponsive">
            <ul className="navbar-nav ml-auto">
              <li className="nav-item " >
                <a
                  className="nav-link js-scroll-trigger"
                  href="/Home"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    // display: "inline-block",
                    display: selectedLanguage === 'en' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faHouse} style={iconStyle}
                    onMouseOver={() => setIconStyle(iconHoverStyle)}
                    onMouseOut={() => setIconStyle({
                      // fontSize: '20px',
                      transition: ' color 0.3s',
                    })}
                  />&nbsp;{translations['en']['home']}
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
                <a
                  className="nav-link js-scroll-trigger"
                  href="/Home"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    // display: "inline-block",
                    display: selectedLanguage === 'ar' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faHouse} style={iconStyle}
                    onMouseOver={() => setIconStyle(iconHoverStyle)}
                    onMouseOut={() => setIconStyle({
                      // fontSize: '20px',
                      transition: ' color 0.3s',
                    })}
                  />&nbsp;{translations['ar']['home']}
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link js-scroll-trigger"
                  href="/about-us"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    display: selectedLanguage === 'en' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faRing} style={abouticon}
                    onMouseOver={() => setAbouticon(aboutHoverStyle)}
                    onMouseOut={() => setAbouticon({
                      fontSize: '20px',
                      transition: 'font-size 0.3s, color 0.3s',
                    })}
                  />&nbsp; {translations['en']['about']}
                  
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
                <a
                  className="nav-link js-scroll-trigger"
                  href="/about-us"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    display: selectedLanguage === 'ar' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faRing} style={abouticon}
                    onMouseOver={() => setAbouticon(aboutHoverStyle)}
                    onMouseOut={() => setAbouticon({
                      fontSize: '20px',
                      color:'#B6B4B4',
                      transition: 'font-size 0.3s, color 0.3s',
                    })}
                  />&nbsp; {translations['ar']['about']}
                  
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link js-scroll-trigger"
                  href="/services"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    display: selectedLanguage === 'en' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faStoreAlt}
                    style={serviceicon}
                    onMouseOver={() => setServiceicon(serviceHoverStyle)}
                    onMouseOut={() => setServiceicon({
                      transition: 'font-size 0.3s, color 0.3s',
                    })}
                  />&nbsp; {translations['en']['services']}
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
                <a
                  className="nav-link js-scroll-trigger"
                  href="/services"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    display: selectedLanguage === 'ar' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faStoreAlt}
                    style={serviceicon}
                    onMouseOver={() => setServiceicon(serviceHoverStyle)}
                    onMouseOut={() => setServiceicon({
                      transition: 'font-size 0.3s, color 0.3s',
                    })}
                  />&nbsp; {translations['ar']['services']}
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link js-scroll-trigger "
                  href="/Jobs"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    display: selectedLanguage === 'en' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faInbox}
                    style={jobicon}
                    onMouseOver={() => setJobicon(jobHoverStyle)}
                    onMouseOut={() => setJobicon({
                      // fontSize: '20px',
                      transition: 'font-size 0.3s, color 0.3s',
                    })}
                  />&nbsp;{translations['en']['jobs']}
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
                <a
                  className="nav-link js-scroll-trigger"
                  href="/Jobs"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    display: selectedLanguage === 'ar' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faInbox}
                    style={jobicon}
                    onMouseOver={() => setJobicon(jobHoverStyle)}
                    onMouseOut={() => setJobicon({
                      // fontSize: '20px',
                      transition: 'font-size 0.3s, color 0.3s',
                    })}
                  />&nbsp;{translations['ar']['jobs']}
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
              </li>
              <li className="nav-item" >
                <a
                  className="nav-link js-scroll-trigger text-secondary"
                  href="/contact"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    display: selectedLanguage === 'en' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faContactBook}
                    style={contacticon}
                    onMouseOver={() => setContacticon(contactHoverStyle)}
                    onMouseOut={() => setContacticon({
                      // fontSize: '20px',
                      transition: 'font-size 0.3s, color 0.3s',
                    })}
                  />&nbsp; {translations['en']['contact']}
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
                <a
                  className="nav-link js-scroll-trigger "
                  href="/contact"
                  style={{
                    position: "relative",
                    textDecoration: "none",
                    display: selectedLanguage === 'ar' ? 'block' : 'none',
                    color:'#2A2A2A'
                  }}
                  onMouseOver={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "100%";
                  }}
                  onMouseOut={(e) => {
                    e.currentTarget.querySelector(".underline").style.width = "0%";
                  }}
                >
                  <FontAwesomeIcon icon={faContactBook}
                    style={contacticon}
                    onMouseOver={() => setContacticon(contactHoverStyle)}
                    onMouseOut={() => setContacticon({
                      // fontSize: '20px',
                      transition: 'font-size 0.3s, color 0.3s',
                    })}
                  />&nbsp; {translations['ar']['contact']}
                  <div
                    className="underline"
                    style={{
                      position: "absolute",
                      bottom: 0,
                      left: 0,
                      right: 0,
                      margin: "auto",
                      backgroundColor: "#FFC20F",
                      width: "0%",
                      height: "4px",
                      transition: "width 0.3s",
                    }}
                  ></div>
                </a>
              </li>
              <li className="nav-item">
        <a className="nav-link" >
            <span className="nav-icon">
                {selectedLanguage&&selectedLanguage=='en'?<img src="https://winch.sa/assets/site/images/SaudiFlag.svg" className="lang-img" alt="" />:<img src="https://winch.sa/assets/site/images/ENflag.svg" class="lang-img" alt=""></img>}
                
            </span>&nbsp;
            {/* <p>{translations[selectedLanguage]['lang-choice']}</p> */}
      {languages.map(language => (
        <span className="nav-link-text text-secondary" key={language.code} style={{ marginRight: '10px', cursor: 'pointer',fontSize:'10px', display: selectedLanguage === language.code ? 'none' : 'inline' }} onClick={() => handleLanguageChange(language.code)}>
          {language.name}
        </span>
      ))}
        </a>
    </li>
            </ul>
          </div>
        </div>
      </nav>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <Routes>
        <Route path="/Home" element={<Home selectedLanguage={selectedLanguage}/>} />
        <Route path="/about-us" element={<About selectedLanguage={selectedLanguage}/>} />
        <Route path='/services' element={<Services selectedLanguage={selectedLanguage}/>} />
        <Route path='/Jobs' element={<Jobs selectedLanguage={selectedLanguage}/>} />
        <Route path='/contact' element={<Contact selectedLanguage={selectedLanguage}/>} />
      </Routes>

      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      {/* <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br>
   <br></br> */}
     {/* <h1 style={{ display: selectedLanguage === 'en' ? 'block' : 'none' }}>{translations['en']['header']}</h1>
      <h1 style={{ display: selectedLanguage === 'ar' ? 'block' : 'none' }}>{translations['ar']['header']}</h1>

      <p style={{ display: selectedLanguage === 'en' ? 'block' : 'none' }}>{translations['en']['paragraf']}</p>
      <p style={{ display: selectedLanguage === 'ar' ? 'block' : 'none' }}>{translations['ar']['paragraf']}</p> */}
      <section className="page-section" id="contact">
        <div className="container">
          <div className="row">
            <div className="col-lg-12 text-center">
              <h2 className="section-heading text-uppercase">Contact Us</h2>
              <h3 className="section-subheading text-muted">Lorem ipsum dolor sit amet consectetur.</h3>
            </div>
          </div>
          <div className="row">
            <div className="col-lg-12">
              <form id="contactForm" name="sentMessage" noValidate>
                <div className="row">
                  <div className="col-md-6">
                    <div className="form-group">
                      <input className="form-control" id="name" type="text" placeholder="Your Name *" required="required" data-validation-required-message="Please enter your name." />
                      <p className="help-block text-danger"></p>
                    </div>
                    <div className="form-group">
                      <input className="form-control" id="email" type="email" placeholder="Your Email *" required="required" data-validation-required-message="Please enter your email address." />
                      <p className="help-block text-danger"></p>
                    </div>
                    <div className="form-group">
                      <input className="form-control" id="phone" type="tel" placeholder="Your Phone *" required="required" data-validation-required-message="Please enter your phone number." />
                      <p className="help-block text-danger"></p>
                    </div>
                  </div>
                  <div className="col-md-6">
                    <div className="form-group">
                      <textarea className="form-control" id="message" placeholder="Your Message *" required="required" data-validation-required-message="Please enter a message."></textarea>
                      <p className="help-block text-danger"></p>
                    </div>
                  </div>
                  <div className="clearfix"></div>
                  <div className="col-lg-12 text-center">
                    <div id="success"></div>
                    <button id="sendMessageButton" className="btn btn-primary btn-xl text-uppercase" type="submit">Send Message</button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </section>
      <footer className="footer bg-secondary">
        <div className="container">
          <div className="row align-items-center">
            <div className="col-md-4">
              <span className="copyright">Copyright &copy; Your Website 2023</span>
            </div>
            <div className="col-md-4">
              <ul className="list-inline social-buttons">
                <li className="list-inline-item">
                  <a href="#something">
                    <i className="fa fa-twitter"></i>
                  </a>
                </li>
                <li className="list-inline-item">
                  <a href="#something">
                    <i className="fa fa-facebook-f"></i>
                  </a>
                </li>
                <li className="list-inline-item">
                  <a href="#something">
                    <i className="fa fa-linkedin"></i>
                  </a>
                </li>
              </ul>
            </div>
            <div className="col-md-4">
              <ul className="list-inline quicklinks">
                <li className="list-inline-item">
                  <a href="#something">Privacy Policy</a>
                </li>
                <li className="list-inline-item">
                  <a href="#something">Terms of Use</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;

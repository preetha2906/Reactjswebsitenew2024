import React from "react";
import { Link } from "react-router-dom";

export default function Contact(){
    return(
        <>
        <main>
        <h1>Contact</h1>
        </main>
        <nav>
            <Link to='/about' >Contact</Link>
        </nav>
        </>
    )
}
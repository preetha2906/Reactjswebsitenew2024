import React from "react";
import { Link } from "react-router-dom";
import {translations} from './translation'

export default function About(props){
    const {selectedLanguage}=props

    return(
        <>
        <main>
        <h1 style={{display: selectedLanguage === 'en' ? 'block' : 'none'}}>{translations['en']['who we are']}</h1>
        <h1 style={{display: selectedLanguage === 'ar' ? 'block' : 'none'}}>{translations['ar']['who we are']}</h1>
        </main>
        <nav>
            <Link to='/about' >Create Our Story</Link>
        </nav>
        </>
    )
}
import React from "react";
import { Link } from "react-router-dom";

export default function About(){
    return(
        <>
        <main>
        <h1>About</h1>
        </main>
        <nav>
            <Link to='/about' >About</Link>
        </nav>
        </>
    )
}
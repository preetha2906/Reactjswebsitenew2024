// LanguageSelect.js
import React from 'react';
import { Dropdown } from 'react-bootstrap';

const LanguageSelect = ({ languages, currentLanguage, onChangeLanguage }) => {
  return (
    <Dropdown>
      <Dropdown.Toggle variant="primary" id="language-dropdown">
        {currentLanguage}
      </Dropdown.Toggle>

      <Dropdown.Menu>
        {languages.map((language) => (
          <Dropdown.Item key={language} onClick={() => onChangeLanguage(language)}>
            {language}
          </Dropdown.Item>
        ))}
      </Dropdown.Menu>
    </Dropdown>
  );
};

export default LanguageSelect;

// import React, { useState } from 'react';

// const languages = [
//   { code: 'en', name: 'English' },
//   { code: 'rus', name: 'Русский' },
//   { code: 'deu', name: 'Deutsch' }
// ];

// const translations = {
//   'en': {
//     'header': 'Spring',
//     'paragraf': 'Hello',
//     'lang-choice': 'Choose your language:'
//   },
//   'deu': {
//     'header': 'Frühling',
//     'paragraf': 'Hallo',
//     'lang-choice': 'Wählen Sie Ihre Sprache:'
//   },
//   'rus': {
//     'header': 'Весна',
//     'paragraf': 'Привет',
//     'lang-choice': 'Выберите ваш язык:'
//   }
// };

// const LanguageSelector = () => {
//   const [selectedLanguage, setSelectedLanguage] = useState('en');

//   const handleLanguageChange = (event) => {
//     setSelectedLanguage(event.target.value);
//   };

//   return (
//     <div>
//       <label htmlFor="languageDropdown">{translations[selectedLanguage]['lang-choice']}</label>
//       <select id="languageDropdown" value={selectedLanguage} onChange={handleLanguageChange}>
//         {languages.map(language => (
//           <option key={language.code} value={language.code}>
//             {language.name}
//           </option>
//         ))}
//       </select>

//       <h1>{translations[selectedLanguage]['header']}</h1>
//       <p>{translations[selectedLanguage]['paragraf']}</p>
//     </div>
//   );
// };

// export default LanguageSelector;
// import React, { useState } from 'react';

// const languages = [
//   { code: 'en', name: 'English' },
//   { code: 'rus', name: 'Русский' },
//   { code: 'deu', name: 'Deutsch' }
// ];

// const translations = {
//   'en': {
//     'header': 'Spring',
//     'paragraf': 'Hello',
//     'lang-choice': 'Choose your language:'
//   },
//   'deu': {
//     'header': 'Frühling',
//     'paragraf': 'Hallo',
//     'lang-choice': 'Wählen Sie Ihre Sprache:'
//   },
//   'rus': {
//     'header': 'Весна',
//     'paragraf': 'Привет',
//     'lang-choice': 'Выберите ваш язык:'
//   }
// };

// const LanguageSelector = () => {
//   const [selectedLanguage, setSelectedLanguage] = useState('en');

//   const handleLanguageChange = (languageCode) => {
//     setSelectedLanguage(languageCode);
//   };

//   return (
//     <div>
//       <p>{translations[selectedLanguage]['lang-choice']}</p>
//       {languages.map(language => (
//         <span key={language.code} style={{ marginRight: '10px', cursor: 'pointer' }} onClick={() => handleLanguageChange(language.code)}>
//           {language.name}
//         </span>
//       ))}
      
//       <h1>{translations[selectedLanguage]['header']}</h1>
//       <p>{translations[selectedLanguage]['paragraf']}</p>
//     </div>
//   );
// };

// export default LanguageSelector;


import React, { useState } from 'react';

const languages = [
  { code: 'en', name: 'English' },
  { code: 'rus', name: 'Русский' }
];

const translations = {
  'en': {
    'header': 'Spring',
    'paragraf': 'Hello',
    'lang-choice': 'Choose your language:'
  },
  'rus': {
    'header': 'Весна',
    'paragraf': 'Привет',
    'lang-choice': 'Выберите ваш язык:'
  }
};

const LanguageSelector = () => {
  const [selectedLanguage, setSelectedLanguage] = useState('en');

  const handleLanguageChange = (languageCode) => {
    setSelectedLanguage(languageCode);
  };

  return (
    <div>
      <p>{translations[selectedLanguage]['lang-choice']}</p>
      {languages.map(language => (
        <span key={language.code} style={{ marginRight: '10px', cursor: 'pointer', display: selectedLanguage === language.code ? 'none' : 'inline' }} onClick={() => handleLanguageChange(language.code)}>
          {language.name}
        </span>
      ))}
      
      <h1 style={{ display: selectedLanguage === 'en' ? 'block' : 'none' }}>{translations['en']['header']}</h1>
      <h1 style={{ display: selectedLanguage === 'rus' ? 'block' : 'none' }}>{translations['rus']['header']}</h1>

      <p style={{ display: selectedLanguage === 'en' ? 'block' : 'none' }}>{translations['en']['paragraf']}</p>
      <p style={{ display: selectedLanguage === 'rus' ? 'block' : 'none' }}>{translations['rus']['paragraf']}</p>
    </div>
  );
};

export default LanguageSelector;

export const paths = {
    index: '/',
    checkout: '/checkout',
    contact: '/contact',
    pricing: '/pricing',
    signup: '/signup',
    settings: {
      index: '/settings',
      bussinessSettings: '/settings/business-settings',
    },
    payment:{
      index: '/payment'
    },
    account: '/account',
    forgot: '/forgot-password',
    verify: '/approve-business',
    selectUser: '/select-user',
    resetPassword: '/reset-password',
    createPassword:'/create-password',
    privacypolicy:'/privacy-policy',
  
    roles: {
      index: '/roles',
      create: '/roles/create',
      details: '/roles/:roleId',
      edit: '/roles/:roleId/edit'
    },
    issueTypes: {
      index: '/issue-types',
      create: '/issue-types/create',
      details: '/issue-types/:issueTypeId',
      edit: '/issue-types/:issueTypeId/edit'
    },
    issuesubTypes: {
      index: '/issue-sub-types',
      create: '/issue-sub-types/create',
      details: '/issue-sub-types/:issuesubTypeId',
      edit: '/issue-sub-types/:issuesubTypeId/edit'
    },
    redeemTypes: {
      index: '/redeem-types',
      create: '/redeem-types/create',
      details: '/redeem-types/:redeemTypeId',
      edit: '/redeem-types/:redeemTypeId/edit'
    },
    redeemSubTypes:
    {
      index: '/redeem-sub-types',
      create: '/redeem-sub-types/create',
      details: '/redeem-sub-types/:redeemSubTypeId',
      edit: '/redeem-sub-types/:redeemSubTypeId/edit'
    },
    redeem: {
      index: '/redeem',
      create: '/redeem/create',
      details: '/redeem/:redeemId',
      edit: '/redeem/:redeemId/edit'
    },
    leaveType: {
      index: '/leave-types',
      create: '/leave-types/create',
      details: '/leave-types/:leaveTypeId',
      edit: '/leave-types/:leaveTypeId/edit'
    },
    leaves: {
      index: '/leaves',
      create: '/leaves/create',
      details: '/leaves/:leaveId',
      edit: '/leaves/:leaveId/edit'
    },
    departments: {
      index: '/departments',
      create: '/departments/create',
      details: '/departments/:departmentId',
      edit: '/departments/:departmentId/edit'
    },
    sections: {
      index: '/sections',
      create: '/sections/create',
      details: '/sections/:sectionId',
      edit: '/sections/:sectionId/edit'
    },
    designations: {
      index: '/designations',
      create: '/designations/create',
      details: '/designations/:designationId',
      edit: '/designations/:designationId/edit'
    },
    positions: {
      index: '/positions',
      create: '/positions/create',
      details: '/positions/:positionId',
      edit: '/positions/:positionId/edit'
    },
    users: {
      index: '/users',
      create: '/users/create',
      details: '/users/:userId',
      edit: '/users/:userId/edit'
    },
    staffs: {
      index: '/staffs',
      create: '/staffs/create', 
      details: '/staffs/:staffId',
      edit: '/staffs/:staffId/edit'
    },
    issuepoints: {
      index: '/issuepoints',
      create: '/issuepoints/create', 
      details: '/issuepoints/:issueId',
      edit: '/issuepoints/:issueId/edit'
    },
    token: {
      index: '/token',
      create: '/token/create', 
      details: '/token/:tokenId',
      edit: '/token/:tokenId/edit'
    },
    allocation: {
      index: '/allocation',
      create: '/allocation/create', 
      details: '/allocation/:allocationId',
      edit: '/allocation/:allocationId/edit'
    },
    holidays: {
      index: '/holidays',
      create: '/holidays/create', 
      details: '/holidays/:holidayId',
      edit: '/holidays/:holidayId/edit'
    },
    shifts: {
      index: '/shifts',
      create: '/shifts/create', 
      details: '/shifts/:shiftId',
      edit: '/shifts/:shiftId/edit'
    },
    workLocations: {
      index: '/work-locations',
      create: '/work-locations/create', 
      details: '/work-locations/:workLocationId',
      edit: '/work-locations/:workLocationId/edit'
    },
    staffTypes: {
      index: '/staff-types',
      create: '/staff-types/create', 
      details: '/staff-types/:staffTypeId',
      edit: '/staff-types/:staffTypeId/edit'
    },
    customerTypes: {
      index: '/customer-types',
      create: '/customer-types/create', 
      details: '/customer-types/:customerTypeId',
      edit: '/customer-types/:customerTypeId/edit'
    },
    members: {
      index: '/members',
      create: '/members/create',
      details: '/members/:memberId',
      edit: '/members/:memberId/edit'
    },
    products: {
      index: '/products',
      create: '/products/create',
      details: '/products/:productId',
      edit: '/products/:productId/edit'
    },
    productCategory: {
      index: '/product-category',
      create: '/product-category/create',
      details: '/product-category/:productCategoryId',
      edit: '/product-category/:productCategoryId/edit'
    },
    auth: {
      auth0: {
        callback: '/auth/auth0/callback',
        login: '/auth/auth0/login'
      },
      jwt: {
        login: '/auth/jwt/login',
        register: '/auth/jwt/register',
      },
      firebase: {
        login: '/auth/firebase/login',
        register: '/auth/firebase/register'
      },
      amplify: {
        confirmRegister: '/auth/amplify/confirm-register',
        forgotPassword: '/auth/amplify/forgot-password',
        login: '/auth/amplify/login',
        register: '/auth/amplify/register',
        resetPassword: '/auth/amplify/reset-password'
      }
    },
    dashboard: {
      index: '/dashboard',
      academy: {
        index: '/dashboard/academy',
        courseDetails: '/dashboard/academy/courses/:courseId'
      },
      account: '/dashboard/account',
      analytics: '/dashboard/analytics',
      blank: '/dashboard/blank',
      blog: {
        index: '/dashboard/blog',
        postDetails: '/dashboard/blog/:postId',
        postCreate: '/dashboard/blog/create'
      },
      calendar: '/dashboard/calendar',
      chat: '/dashboard/chat',
      crypto: '/dashboard/crypto',
      members: {
        index: '/dashboard/members',
        details: '/dashboard/members/:memberId',
        edit: '/dashboard/members/:memberId/edit'
      },
      ecommerce: '/dashboard/ecommerce',
      fileManager: '/dashboard/file-manager',
      invoices: {
        index: '/dashboard/invoices',
        details: '/dashboard/invoices/:orderId'
      },
      jobs: {
        index: '/dashboard/jobs',
        create: '/dashboard/jobs/create',
        companies: {
          details: '/dashboard/jobs/companies/:companyId'
        }
      },
      kanban: '/dashboard/kanban',
      logistics: {
        index: '/dashboard/logistics',
        fleet: '/dashboard/logistics/fleet'
      },
      mail: '/dashboard/mail',
      orders: {
        index: '/dashboard/orders',
        details: '/dashboard/orders/:orderId'
      },
      products: {
        index: '/dashboard/products',
        create: '/dashboard/products/create'
      },
      social: {
        index: '/dashboard/social',
        profile: '/dashboard/social/profile',
        feed: '/dashboard/social/feed'
      }
    },
    components: {
      index: '/components',
      dataDisplay: {
        detailLists: '/components/data-display/detail-lists',
        tables: '/components/data-display/tables',
        quickStats: '/components/data-display/quick-stats'
      },
      lists: {
        groupedLists: '/components/lists/grouped-lists',
        gridLists: '/components/lists/grid-lists'
      },
      forms: '/components/forms',
      modals: '/components/modals',
      charts: '/components/charts',
      buttons: '/components/buttons',
      typography: '/components/typography',
      colors: '/components/colors',
      inputs: '/components/inputs'
    },
    docs: 'https://material-kit-pro-react-docs.devias.io',
    notAuthorized: '/401',
    notFound: '/404',
    serverError: '/500'
  };
  
export default function head(){
    return(
        <>
        <h1>head Page</h1>
        </>
    )
}
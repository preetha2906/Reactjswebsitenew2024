import Image from "next/image";
import styles from "./page.module.css";
import RootLayout from '../components/RootLayout';
import Footer from "./common/footer"
import Header from "./common/header"
export default function Home() {
  return (
    <RootLayout>
       <Header />
      {/* Your page content goes here */}
      <h1>Hello, Nextjs!</h1>
      <Footer />
    </RootLayout>
  );
}

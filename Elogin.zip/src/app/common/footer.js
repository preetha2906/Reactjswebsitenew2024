import Link from "next/link";


export default function Footer(){
    return(
        <>
         <div >
            <footer>
                Footer section!!
            </footer>
       
        </div>
        </>
    )
}
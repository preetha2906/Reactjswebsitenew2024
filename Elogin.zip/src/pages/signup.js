import {
  Card,
  CardHeader,
  CardContent,
  Typography,
  Stack,
  TextField,
  InputAdornment,
  IconButton,
  Checkbox,
  FormHelperText,
  Button,
} from '@mui/material';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import styled from '@emotion/styled';
import { useRouter } from "next/router";
// import { Link } from 'next/link';
import { RouterLink } from '../components/router-link';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import { paths } from '../paths'
import axios from 'axios'

const initialValues = {
  email: '',
  name: '',
  password: '',
  passwordConfirm: '',
  phone: '',
  policy: false,
  submit: null
};
const validationSchema = Yup.object({
  email: Yup
    .string()
    .email('Must be a valid email')
    .max(255)
    .required('Email is required'),
  name: Yup
    .string()
    .max(255)
    .matches(/^[A-Za-z\s]+$/, 'Only alphabetic characters are allowed')
    .required('Name is required'),
  phone: Yup
    .string()
    .matches(/^[0-9]+$/, 'Phone must contain only numeric characters')
    .max(16)
    .required('Phone is required'),
  password: Yup
    .string()
    .min(7)
    .max(255)
    .required('Password is required'),
  passwordConfirm: Yup
    .string()
    .oneOf([Yup.ref('password')], 'Passwords must match')
    .required('Confirm password is Required'),
  policy: Yup
    .boolean()
    .oneOf([true], 'Please Accept Terms & Conditions')
});

const signup = () => {
  const [isClient, setIsClient] = useState(false)

  const [showPassword, setShowPassword] = useState(false)
  const [confirmPass, setConfirmPass] = useState(false);
  const router = useRouter()

  useEffect(() => {
    setIsClient(true)
  }, [])
  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: async (values, helpers) => {
      try {
        var formdata = {
          name: values.name,
          email: values.email,
          password: values.password,
          confirmpassword: values.passwordConfirm,
          phone: values.phone,
          policy: values.policy
        }
        const result = await axios.post('http://localhost:4000/register', formdata);
        console.warn(result);
        localStorage.setItem("user", JSON.stringify(result))
        router.push('/login')

      } catch (error) {
        console.error(error);
      }
    }
  });
  // useEffect(() => {
  //   const auth = localStorage.getItem('user')
  //   if (auth) {
  //     router.push('/')
  //   }
  // }, [])
  console.log("89786856456",formik.values)
  return <>{isClient ? <div>
    <h1 style={{ color: 'red', marginLeft: '500px' }}>Welcome To Signup page</h1>
    <div>
      <Card style={{ maxWidth: '50%' }} sx={{ marginLeft: 50 }}>
        <CardHeader
          subheader={(
            <Typography
              color="text.secondary"
              variant="body2"
            >
              Already have an account?? &nbsp;<a href='/login'>Please Login</a>
              &nbsp;
              {/* <Link
            //   component={RouterLink}
            //   href={paths.index}
              underline="hover"
              variant="subtitle2"
            >
              Log in
            </Link> */}
            </Typography>
          )}
          sx={{ pb: 0 }}
          title="Signup Form"
        />
        <CardContent>
          <form
            noValidate
            onSubmit={formik.handleSubmit}
          >
            <Stack spacing={3}>
              <TextField
                error={!!(formik.touched.name && formik.errors.name)}
                fullWidth
                helperText={formik.touched.name && formik.errors.name}
                label="Business Name"
                name="name"
                onBlur={formik.handleBlur}
                onChange={(e) => {
                  const trimmedValue = e.target.value.trimStart();
                  formik.handleChange(e);
                  formik.setFieldValue('name', trimmedValue);
                }}
                value={formik.values.name}
              />
              <TextField
                error={!!(formik.touched.email && formik.errors.email)}
                fullWidth
                helperText={formik.touched.email && formik.errors.email}
                label="Email Address"
                name="email"
                onBlur={formik.handleBlur}
                onChange={(e) => {
                  const trimmedValue = e.target.value.trimStart();
                  formik.handleChange(e);
                  formik.setFieldValue('email', trimmedValue);
                }}
                value={formik.values.email}
              />
              <TextField
                error={!!(formik.touched.phone && formik.errors.phone)}
                fullWidth
                helperText={formik.touched.phone && formik.errors.phone}
                label="Phone"
                name="phone"
                onBlur={formik.handleBlur}
                onChange={(e) => {
                  const trimmedValue = e.target.value.trimStart();
                  formik.handleChange(e);
                  formik.setFieldValue('phone', trimmedValue);
                }}
                value={formik.values.phone}
              />
              <TextField
                error={!!(formik.touched.password && formik.errors.password)}
                fullWidth
                helperText={formik.touched.password && formik.errors.password}
                label="Password"
                name="password"
                onBlur={formik.handleBlur}
                onChange={(e) => {
                  const trimmedValue = e.target.value.trimStart();
                  formik.handleChange(e);
                  formik.setFieldValue('password', trimmedValue);
                }}
                type={showPassword ? "text" : "password"}
                value={formik.values.password}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position='end'>
                      <IconButton
                        onClick={() => setShowPassword(!showPassword)}
                        edge="end">
                        {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                      </IconButton>
                    </InputAdornment>
                  )

                }}
              />
              <TextField
                error={!!(formik.touched.passwordConfirm && formik.errors.passwordConfirm)}
                fullWidth
                helperText={formik.touched.passwordConfirm && formik.errors.passwordConfirm}
                label=" Confirm Password "
                name="passwordConfirm"
                onBlur={formik.handleBlur}
                onChange={(e) => {
                  const trimmedValue = e.target.value.trimStart();
                  formik.handleChange(e);
                  formik.setFieldValue('passwordConfirm', trimmedValue);
                }}
                type={confirmPass ? "text" : "password"}
                value={formik.values.passwordConfirm}
                InputProps={{
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton
                        onClick={() => setConfirmPass(!confirmPass)}
                        edge="end"
                      >
                        {confirmPass ? <VisibilityOffIcon /> : <VisibilityIcon />}
                      </IconButton>
                    </InputAdornment>
                  ),
                }}
              />
            </Stack>
            <Box
              sx={{
                alignItems: 'center',
                display: 'flex',
                ml: -1,
                mt: 1
              }}
            >
              <Checkbox
                checked={formik.values.policy}
                name="policy"
                onChange={formik.handleChange}
              />
              <Typography
                color="text.secondary"
                variant="body2"
              >
                I have read the <a href=''>Terms and Conditions</a>
                {' '}
                {/* <Link
                 component={RouterLink}
                 href={paths.privacypolicy}
              >
                Terms and Conditions
              </Link> */}
              </Typography>
            </Box>
            {!!(formik.touched.policy && formik.errors.policy) && (
              <FormHelperText error>
                {formik.errors.policy}
              </FormHelperText>
            )}
            {formik.errors.submit && (
              <FormHelperText
                error
                sx={{ mt: 3 }}
              >
                {formik.errors.submit}
              </FormHelperText>
            )}
            <Button
              disabled={formik.isSubmitting}
              fullWidth
              size="large"
              sx={{ mt: 2 }}
              type="submit"
              variant="contained"
            >
              Register
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  </div> : 'Prerendered'}</>

}
export default signup;
import {
    Card,
    CardHeader,
    CardContent,
    Typography,
    Stack,
    TextField,
    InputAdornment,
    IconButton,
    Checkbox,
    FormHelperText,
    Button,
  } from '@mui/material';
  import VisibilityIcon from '@mui/icons-material/Visibility';
  import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
  import styled from '@emotion/styled';
import { useRouter } from "next/router";
import { Link } from 'next/link';
import { RouterLink } from '../components/router-link';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import {paths} from '../paths'
import axios from 'axios'
import { useRef } from 'react';
import { useNavigate } from 'react-router-dom';
const initialValues = {
    email: '',
    password: '',
    submit: null
  };
  const validationSchema = Yup.object({
    email: Yup
      .string()
      .email('Must be a valid email')
      .max(255)
      .required('Email is required'),
    password: Yup
      .string()
      .min(7)
      .max(255)
      .required('Password is required')
  });
export default function Login(){
    const [showPassword, setShowPassword] = useState(false)
    const [confirmPass, setConfirmPass] = useState(false);
    const router = useRouter()

  
    const formik = useFormik({
        initialValues,
        validationSchema,
        onSubmit: async (values, helpers) => {
          try {
            const formdata={
              email:values.email,
              password:values.password
            }
            console.log("formdata",formdata)
            const result = await axios.post('http://localhost:4000/sign-in', formdata);
            console.warn(result);
            localStorage.setItem("user",JSON.stringify(result))
            navigate('/')
          } 
          catch (error) {
            console.error(error);
          }
        }
      });
    console.log("89786576",formik.values)
    return(
        <div>
            <h1 style={{color:'red',marginLeft:'500px'}}>Welcome to login page</h1>
            <div>
        <Card style={{maxWidth:'50%'}} sx={{marginLeft:50}}>
          <CardHeader
            subheader={(
              <Typography
                color="text.secondary"
                variant="body2"
              >
                Don't have an account? &nbsp;<a href='/signup'>Please signup</a>
                &nbsp;
                {/* <Link href="/signup">
        <a>Please signup</a>
      </Link> */}
                {/* <Link
                //   component={RouterLink}
                //   href={paths.index}
                  underline="hover"
                  variant="subtitle2"
                >
                  Log in
                </Link> */}
              </Typography>
            )}
            sx={{ pb: 0 }}
            title="Login Form"
          />
          <CardContent>
            <form
              noValidate
              onSubmit={formik.handleSubmit}
            >
              <Stack spacing={3}>
                {/* <TextField
                  error={!!(formik.touched.name && formik.errors.name)}
                  fullWidth
                  helperText={formik.touched.name && formik.errors.name}
                  label="Business Name"
                  name="name"
                  onBlur={formik.handleBlur}
                  onChange={(e) => {
                    const trimmedValue = e.target.value.trimStart();
                    formik.handleChange(e);
                    formik.setFieldValue('name', trimmedValue);
                  }}
                  value={formik.values.name}
                /> */}
                <TextField
                  error={!!(formik.touched.email && formik.errors.email)}
                  fullWidth
                  helperText={formik.touched.email && formik.errors.email}
                  label="Email Address"
                  name="email"
                  onBlur={formik.handleBlur}
                  onChange={(e) => {
                    const trimmedValue = e.target.value.trimStart();
                    formik.handleChange(e);
                    formik.setFieldValue('email', trimmedValue);
                  }}
                  value={formik.values.email}
                />
                {/* <TextField
                  error={!!(formik.touched.phone && formik.errors.phone)}
                  fullWidth
                  helperText={formik.touched.phone && formik.errors.phone}
                  label="Phone"
                  name="phone"
                  onBlur={formik.handleBlur}
                  onChange={(e) => {
                    const trimmedValue = e.target.value.trimStart();
                    formik.handleChange(e);
                    formik.setFieldValue('phone', trimmedValue);
                  }}
                  value={formik.values.phone}
                /> */}
                <TextField
                  error={!!(formik.touched.password && formik.errors.password)}
                  fullWidth
                  helperText={formik.touched.password && formik.errors.password}
                  label="Password"
                  name="password"
                  onBlur={formik.handleBlur}
                  onChange={(e) => {
                    const trimmedValue = e.target.value.trimStart();
                    formik.handleChange(e);
                    formik.setFieldValue('password', trimmedValue);
                  }}
                  type={showPassword ? "text":"password"}
                  value={formik.values.password}
                  InputProps={{
                    endAdornment:(
                      <InputAdornment position='end'>
                        <IconButton
                          onClick={() => setShowPassword(!showPassword)}
                          edge="end">
                          {showPassword ? <VisibilityOffIcon /> : <VisibilityIcon />}
                        </IconButton>
                      </InputAdornment>
                    )

                  }}
                />
                 {/* <TextField
                  error={!!(formik.touched.passwordConfirm && formik.errors.passwordConfirm)}
                  fullWidth
                  helperText={formik.touched.passwordConfirm && formik.errors.passwordConfirm}
                  label=" Confirm Password "
                  name="passwordConfirm"
                  onBlur={formik.handleBlur}
                  onChange={(e) => {
                    const trimmedValue = e.target.value.trimStart();
                    formik.handleChange(e);
                    formik.setFieldValue('passwordConfirm', trimmedValue);
                  }}
                  type={confirmPass ? "text" : "password"}
                  value={formik.values.passwordConfirm}
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <IconButton
                          onClick={() => setConfirmPass(!confirmPass)}
                          edge="end"
                        >
                          {confirmPass ? <VisibilityOffIcon /> : <VisibilityIcon />}
                        </IconButton>
                      </InputAdornment>
                    ),
                  }}
                /> */}
              </Stack>
              {/* {!!(formik.touched.policy && formik.errors.policy) && (
                <FormHelperText error>
                  {formik.errors.policy}
                </FormHelperText>
              )} */}
              {formik.errors.submit && (
                <FormHelperText
                  error
                  sx={{ mt: 3 }}
                >
                  {formik.errors.submit}
                </FormHelperText>
              )}
              <Button
                disabled={formik.isSubmitting}
                fullWidth
                size="large"
                sx={{ mt: 2 }}
                type="submit"
                variant="contained"
              >
                Login
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
        </div>
    )
}
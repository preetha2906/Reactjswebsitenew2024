// components/Head.js
import NextHead from 'next/head';

const Head = () => {
  return (
    <NextHead>
      <meta charSet="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      {/* Add other meta tags and links as needed */}
      <title>NextJS Metdata</title>
      <meta name="description" content='Website' />
      {/* Add other meta tags as needed */}
    </NextHead>
  );
};

export default Head;
